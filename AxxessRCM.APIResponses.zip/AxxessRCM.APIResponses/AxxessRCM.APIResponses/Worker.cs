using AxxessRCM.APIResponses.Helpers;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AxxessRCM.APIResponses
{
    public class Worker : BackgroundService
    {
        //private readonly ILogger<Worker> _logger;

        //public Worker(ILogger<Worker> logger)
        //{
        //    _logger = logger;
        //}
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            //-- INITIALIZE API SETTINGS
            APIHelper.InitializeClient();
            APIConfigHelper.InitializeAPIConfig();

            return base.StartAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            //while (!stoppingToken.IsCancellationRequested)
            //{
            //    _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
            //    await Task.Delay(1000, stoppingToken);
            //}
            while (!stoppingToken.IsCancellationRequested)
            {

                //-- RUN TEST API CALL
                var test = await RemittanceResponseManager.FetchTest(APIConfigHelper.TestEndPoint, 1);
                Console.WriteLine($"{test.Id}, {test.Body}");

                //-- RUN TEST CALL FOR FETCHING AND SAVING DATA
                //await JournalResponseManager.FetchResponseB("testendpont", "testToken");

                await Task.Delay(1000, stoppingToken);
            }
        }
    }
}
