﻿using AxxessRCM.APIResponses.Helpers;
using AxxessRCM.APIResponses.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AxxessRCM.APIResponses
{
    public static class RemittanceResponseManager
    {
        /// <summary>
        /// TEST API CALL
        /// </summary>
        /// <param name="baseEndPoint"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static async Task<TestModel> FetchTest(string baseEndPoint, int id)
        {
            var apiEndPoint = new Uri($"{baseEndPoint}/{id}");

            using (HttpResponseMessage response = await APIHelper.ApiClient.GetAsync(apiEndPoint))
            {
                if (response.IsSuccessStatusCode)
                {
                    TestModel testModel = await response.Content.ReadAsAsync<TestModel>();

                    return testModel;
                }
                else
                {
                    throw new Exception(response.ReasonPhrase);
                }
            }
        }
    }
}
