﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AxxessRCM.APIResponses.Helpers
{
    public static class APIConfigHelper
    {
        public static string SubjectId { get; private set; } //-- From Service User Account Table of the Agency
        public static string Password { get; private set; } //-- From Service User Account Table of the Agency

        public static string JournaLEndPoint { get; private set; } //-- From Config
        public static string VolumeEndPoint { get; private set; } //-- From Config
        public static string TestEndPoint { get; private set; } //-- Test End Point

        public static void InitializeAPIConfig()
        {
            //-- Retrieve values of the ff from the DB
            SubjectId = string.Empty;
            Password = string.Empty;

            //-- Retrieve values of the ff form config
            //JournaLEndPoint = string.Empty;
            //VolumeEndPoint = string.Empty;
            TestEndPoint = "https://jsonplaceholder.typicode.com/posts";
        }
    }
}
